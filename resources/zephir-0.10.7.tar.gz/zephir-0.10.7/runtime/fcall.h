
zephir_compiled_expr *zephir_fcall_compile(zephir_context *context, zval *expr TSRMLS_DC);