
#ifndef PHP_ZEPHIR_RUNTIME_EXPR_H
#define PHP_ZEPHIR_RUNTIME_EXPR_H

zephir_compiled_expr *zephir_expr(zephir_context *context, zval *expr TSRMLS_DC);

#endif