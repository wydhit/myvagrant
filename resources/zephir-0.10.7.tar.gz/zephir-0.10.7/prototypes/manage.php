<?php
namespace MongoDB\Driver;

class Manage
{
    public function __construct($uri,  $options, $driverOptions)
    {

    }

    public function executeQuery($namespace, $query, $readPreference)
    {

    }

    public function executeBulkWrite($namespace, $bulk, $writeConcern)
    {

    }

    public function executeCommand($db, $command, $readPreference)
    {

    }

    public function getServers()
    {

    }

    public function selectServer($readPreference)
    {

    }
}
